<?php 
	session_start();
	
	if (isset($_SESSION['id']) || isset($_SESSION['name'])) {
	  header("Location: index.php");
	  exit();
}
	//include header file
	include ('include/header.php');
	include('include/config.php');
	  // Check if the form is submitted
	  if(isset($_POST['SignIn'])) {
		// Retrieve the form data
		$email_phone = $_POST['email_phone'];
		$password = $_POST['password'];
	
		// Assuming 'donor' is the table name in the database
	
		// Perform your desired operations with the form data, such as database operations
	
		// Prepare and execute the SQL query
		$sql = "SELECT * FROM donor WHERE (email = '$email_phone' OR contact_no = '$email_phone') AND password = '$password'";
		$result = $connection->query($sql);
	
		if ($result->num_rows > 0) {
		  // User authenticated successfully
		  echo "Login successful";
		  session_start();
			$row = $result->fetch_assoc();
			$_SESSION['id'] = $row['id']; // Assuming 'id' is the column for user ID in the 'donor' table
			$_SESSION['name'] = $row['name']; // Assuming 'name' is the column for user name in the 'donor' table
			header("Location: index.php");
			exit();
		} else {
		  // Invalid credentials
		  echo "Invalid username or password";
		}
	
	  }
?>

<style>
	.size{
		min-height: 0px;
		padding: 60px 0 60px 0;

	}
	h1{
		color: white;
	}
	.form-group{
		text-align: left;
	}
	h3{
		color: #e74c3c;
		text-align: center;
	}
	.red-bar{
		width: 25%;
	}
	.form-container{
		background-color: white;
		border: .5px solid #eee;
		border-radius: 5px;
		padding: 20px 10px 20px 30px;
		-webkit-box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
-moz-box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
box-shadow: 0px 2px 5px -2px rgba(89,89,89,0.95);
	}
</style>
 <div class="container-fluid red-background size">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h1 class="text-center">SignIn</h1>
			<hr class="white-bar">
		</div>
	</div>
</div>
<div class="conatiner size ">
	<div class="row">
		<div class="col-md-6 offset-md-3 form-container">
		<h3>SignIn</h3>
		<hr class="red-bar">
		
		<!-- Erorr Messages -->

			<form action="" method="post" >
				<div class="form-group">
					<label for="email">Email/Phone no.</label>
					<input type="text" name="email_phone" class="form-control" placeholder="Email Or Phone" required>
				</div>
				<div class="form-group">
					<label for="password">Password</label>
					<input type="password" name="password" placeholder="Password" required class="form-control">
				</div>
				<div class="form-group">
					<button class="btn btn-danger btn-lg center-aligned" type="submit" name="SignIn">SignIn</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php include 'include/footer.php' ?>
