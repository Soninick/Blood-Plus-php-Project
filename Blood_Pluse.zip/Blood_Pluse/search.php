<!DOCTYPE html>
<html>
<head>
	<title>Search Donors</title>
	<!-- Add your CSS styles here -->
	<?php 
		// Include header file
		include('include/header.php');
	?>
	<style>
		.size {
			min-height: 0px;
			padding: 60px 0 40px 0;
		}
		.loader {
			display: none;
			width: 69px;
			height: 89px;
			position: absolute;
			top: 25%;
			left: 50%;
			padding: 2px;
			z-index: 1;
		}
		.loader .fa {
			color: #e74c3c;
			font-size: 52px !important;
		}
		.donors_data {
			background-color: white;
			border-radius: 5px;
			margin: 25px;
			box-shadow: 0px 2px 5px -2px rgba(89, 89, 89, 0.95);
			padding: 20px 10px 20px 30px;
		}
	</style>
</head>
<body>
	<div class="container-fluid red-background size">
		<div class="row">
			<div class="col-md-6 offset-md-3">
				<h1 class="text-center">Search Donors</h1>
				<hr class="white-bar">
				<br>
				<div class="form-inline text-center" style="padding: 40px 0px 0px 5px;">
					<div class="form-group text-center center-aligned">
						<select style="width: 220px; height: 45px;" name="city" id="city" class="form-control demo-default" required>
							<option value="">-- Select --</option>
							<optgroup title="Gujarat" label="&raquo; Gujarat">
								<option value="Ahmedabad">Ahmedabad</option>
								<option value="Surat">Surat</option>
								<option value="Vadodara">Vadodara</option>
								<option value="Rajkot">Rajkot</option>
								<option value="Gandhinagar">Gandhinagar</option>
								<option value="Bhavnagar">Bhavnagar</option>
								<option value="Jamnagar">Jamnagar</option>
								<!-- Add more cities from Gujarat here -->
							</optgroup>
							<optgroup title="Maharashtra" label="&raquo; Maharashtra">
								<option value="Mumbai">Mumbai</option>
								<option value="Pune">Pune</option>
								<option value="Nagpur">Nagpur</option>
								<option value="Thane">Thane</option>
								<option value="Nashik">Nashik</option>
								<option value="Kolhapur">Kolhapur</option>
								<option value="Aurangabad">Aurangabad</option>
								<!-- Add more cities from Maharashtra here -->
							</optgroup>
							<!-- Add more states and cities in a similar format -->
						</select>
					</div>
					<div class="form-group center-aligned">
						<select name="blood_group" id="blood_group" style="padding: 0 20px; width: 220px; height: 45px;" class="form-control demo-default text-center margin10px">
							<option value="A+">A+</option>
							<option value="A-">A-</option>
							<option value="B+">B+</option>
							<option value="B-">B-</option>
							<option value="AB+">AB+</option>
							<option value="AB-">AB-</option>
							<option value="O+">O+</option>
							<option value="O-">O-</option>
						</select>
					</div>
					<div class="form-group center-aligned">
						<button type="button" class="btn btn-lg btn-default" id="search">Search</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container" style="padding: 60px 0 60px 0;">
		<div class="row" id="data">
			<!-- Display the search result -->
			<?php
				if (isset($_GET['city']) && !empty($_GET['city']) && isset($_GET['blood_group']) && !empty($_GET['blood_group'])) {
					$city = $_GET['city'];
					$blood_group = $_GET['blood_group'];
					$sql = "SELECT * FROM DONOR WHERE city='$city' OR blood_group='$blood_group'";
					$result = mysqli_query($connection, $sql);
					
					if (mysqli_num_rows($result) > 0) {
						echo '<div class="container"><div class="row data"><div class="card-body"><h5 class="card-title">Search Result</h5><table class="table table-dark"><thead class="table-primary"><tr><th scope="col">name</th><th scope="col">city</th><th scope="col">blood_group</th><th scope="col">gender</th><th scope="col">contact_no</th><th scope="col">createdAt</th></tr></thead><tbody>';
						
						while ($row = mysqli_fetch_assoc($result)) {
							echo '<tr>';
							echo '<td>' . $row['name'] . '</td>';
							echo '<td>' . $row['city'] . '</td>';
							echo '<td>' . $row['blood_group'] . '</td>';
							echo '<td>' . $row['gender'] . '</td>';
							echo '<td>' . $row['contact_no'] . '</td>';
							echo '<td>' . date("d M Y h:i:s A", strtotime($row['createdAt'])) . '</td>';
							echo '</tr>';
						}
						
						echo '</tbody></table></div></div></div>';
					} else {
						echo '<h3 class="text-center">No donors found</h3>';
					}
				}
			?>
		</div>
	</div>
	<div class="loader" id="wait">
		<i class="fa fa-circle-o-notch fa-spin" aria-hidden="true"></i>
	</div>
	<!-- Add your JavaScript code here -->
	<script>
		// Add your JavaScript code for handling the search and displaying results
		document.getElementById('search').addEventListener('click', function() {
			var city = document.getElementById('city').value;
			var bloodGroup = document.getElementById('blood_group').value;
			
			// Show loader
			document.getElementById('wait').style.display = 'block';
			
			// Perform AJAX request
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					// Hide loader
					document.getElementById('wait').style.display = 'none';
					
					// Update the data div with search results
					document.getElementById('data').innerHTML = this.responseText;
				}
			};
			xhttp.open('GET', 'search_result.php?city=' + city + '&blood_group=' + bloodGroup, true);
			xhttp.send();
		});
	</script>
</body>
</html>
<?php 
	// Include footer file
	include('include/footer.php');
?>
<script type="text/javascript">
	$(function(){
		$("#search").on('click', function(){
			var city = $("#city").val();
			var blood_group = $("#blood_group").val();
			$.ajax({
				type: 'get',
				url: 'ajaxsearch.php',
				data: {city: city, blood_group, blood_group},
				success: function(data){
					if(!data.error){
						$("#data").html(data);
					}
				}
			});
		});
	});
</script>
