<?php
	include('include/config.php');

	if (isset($_GET['city']) && !empty($_GET['city']) && isset($_GET['blood_group']) && !empty($_GET['blood_group'])) {
		$city = $_GET['city'];
		$blood_group = $_GET['blood_group'];
		$sql = "SELECT * FROM DONOR WHERE city='$city' OR blood_group='$blood_group'";
		$result = mysqli_query($connection, $sql);
		
		if (mysqli_num_rows($result) > 0) {
			echo '<div class="container"><div class="row data"><div class="card-body"><h5 class="card-title">Search Result</h5><table class="table table-dark"><thead class="table-primary"><tr><th scope="col">name</th><th scope="col">city</th><th scope="col">blood_group</th><th scope="col">gender</th><th scope="col">contact_no</th><th scope="col">createdAt</th></tr></thead><tbody>';
			
			while ($row = mysqli_fetch_assoc($result)) {
				echo '<tr>';
				echo '<td>' . $row['name'] . '</td>';
				echo '<td>' . $row['city'] . '</td>';
				echo '<td>' . $row['blood_group'] . '</td>';
				echo '<td>' . $row['gender'] . '</td>';
				echo '<td>' . $row['contact_no'] . '</td>';
				echo '<td>' . date("d M Y h:i:s A", strtotime($row['createdAt'])) . '</td>';
				echo '</tr>';
			}
			
			echo '</tbody></table></div></div></div>';
		} else {
			echo '<h3 class="text-center">No donors found</h3>';
		}
	}
?>
