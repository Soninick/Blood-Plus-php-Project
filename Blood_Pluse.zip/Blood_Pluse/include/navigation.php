<?php 
session_start();
$isLoggedIn = isset($_SESSION['id']) && isset($_SESSION['name']);
?>

<!DOCTYPE html>
<html>
<head>
  <title>BLOOD PLUSE</title>
  <!-- Add your CSS and JavaScript file links here -->
</head>
<body>

<!-- Navigation starts -->
<nav id="mainNav" class="navbar fixed-top navbar-default navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="./index.php">BLOOD PLUSE</a>
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <!-- Add your navigation links here if needed -->
    </ul>
    
    <ul class="navbar-nav form-inline my-2 my-lg-0">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>

      <?php
      if (!$isLoggedIn) {
        // Show the "Register" navigation link
        echo '
        <li class="nav-item">
          <a class="nav-link" href="donate.php">Register</a>
        </li>';
      }

      if ($isLoggedIn) {
        echo '
        <li class="nav-item">
          <a class="nav-link" href="donor.php">Donors</a>
        </li>';
      }
      ?>

      <li class="nav-item">
        <a class="nav-link" href="search.php">Search</a>
      </li>

      <?php
      if (!$isLoggedIn) {
        // Show the "Sign in" navigation link
        echo '
        <li class="nav-item">
          <a class="nav-link" href="signin.php">Sign in</a>
        </li>';
      }
      ?>

      <li class="nav-item">
        <a class="nav-link" href="about.php">About Us</a>
      </li>

      <?php
      if ($isLoggedIn) {
        // Show the "Logout" navigation link
        echo '
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>';
      }
      ?>

    </ul>
  </div>
</nav>

<!-- Add the rest of your HTML content here -->

</body>
</html>
