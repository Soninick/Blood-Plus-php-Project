<!-- <?php 
$connection = mysqli_connect("localhost","root","","donatetheblood") or die("Database is not connected.".mysqli_connect_error());
?> -->