<?php 
            require_once('include/config.php'); 
            $sql = "SELECT * FROM DONOR";
            $result = mysqli_query($connection,$sql);
            
            while ($row = mysqli_fetch_assoc($result)) {
				echo '
					                    
						  <tr>
							<TD>'.$row['name'].'</TD>
							<TD>'.$row['city'].'</TD>
							<TD>'.$row['blood_group'].'</TD>
							<TD>'.$row['gender'].'</TD>                                                   
							<TD>'.date("d M Y h:i:s A", strtotime($row['createdAt'])).'</TD>                                                   
						  </tr>
				';
			}
			
        ?>





